#!/bin/sh

BYTES_PER_MEGABYTE=1000000

# read and export nested environment variables to make them accessible to metricbeat

export CLS_HOST=$(echo $VCAP_SERVICES | jq -r '."cloud-logging"? | .[0]? | ."credentials"? | ."Fluentd-endpoint"')
export CLS_USER=$(echo $VCAP_SERVICES | jq -r '."cloud-logging"? | .[0]? | ."credentials"? | ."Fluentd-username"')
export CLS_PASSWD=$(echo $VCAP_SERVICES | jq -r '."cloud-logging"? | .[0]? | ."credentials"? | ."Fluentd-password"')

export VCAP_PLAN_NAME=$(echo $VCAP_SERVICES | jq -r '."cloud-logging"? | .[0]? | ."plan"')
export VCAP_SERVICE_NAME=$(echo $VCAP_SERVICES | jq -r '."cloud-logging"? | .[0]? | ."label"')

export VCAP_APPLICATION_ID=$(echo $VCAP_APPLICATION | jq -r '."application_id"')
export VCAP_APPLICATION_NAME=$(echo $VCAP_APPLICATION | jq -r '."application_name"')
export VCAP_ORGANIZATION_ID=$(echo $VCAP_APPLICATION | jq -r '."organization_id"')
export VCAP_ORGANIZATION_NAME=$(echo $VCAP_APPLICATION | jq -r '."organization_name"')
export VCAP_SPACE_ID=$(echo $VCAP_APPLICATION | jq -r '."space_id"')
export VCAP_SPACE_NAME=$(echo $VCAP_APPLICATION | jq -r '."space_name"')

export VCAP_APPLICATION_LIMIT_FDS=$(($(echo $VCAP_APPLICATION | jq -r '."limits" | ."fds"') * $BYTES_PER_MEGABYTE ))
export VCAP_APPLICATION_LIMIT_MEM=$(($(echo $VCAP_APPLICATION | jq -r '."limits" | ."mem"') * $BYTES_PER_MEGABYTE ))
export VCAP_APPLICATION_LIMIT_DISK=$(($(echo $VCAP_APPLICATION | jq -r '."limits" | ."disk"') * $BYTES_PER_MEGABYTE ))

# check if Fluentd endpoint is provided
if [[ "${CLS_HOST}" == "null" ]]; then 
    echo "No Cloud Logging service instance found, aborting process. Maybe check the instance name."
else 
    echo "Cloud Logging serivce instance found. Downloading and configuring telegraf..."
    
    # download and extract telegraf release
    wget https://dl.influxdata.com/telegraf/releases/telegraf-1.21.2_linux_amd64.tar.gz
    tar xf telegraf-1.21.2_linux_amd64.tar.gz
    
    # start metricbeat using the telegraf.conf configuration file
    ./telegraf-1.21.2/usr/bin/telegraf --config telegraf/telegraf.conf
fi


